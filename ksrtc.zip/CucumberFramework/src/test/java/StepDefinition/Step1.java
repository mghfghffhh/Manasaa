package StepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObject.Login;
import PageObject.UserRegister;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Step1 {
	public WebDriver driver;
	public UserRegister ur;
	public Login lo;

	@Given("User Launch Chrome browser")
	public void user_launch_chrome_browser() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\mindtree2057\\eclipse-workspace\\CucumberFramework\\target\\chromedriver.exe");
		driver = new ChromeDriver();
		ur = new UserRegister(driver);
		lo = new Login(driver);

	}

	@Then("User opens url {string}")
	public void user_opens_url_something(String url) {
		driver.get(url);
		driver.manage().window().maximize();

	}

	@Then("user clicks on signup button")
	public void user_clicks_on_signup_button() throws InterruptedException {
		ur.Register();
	}

	@Then("user enters user Id {string} and new password as {string} and confirm password as {string}")
	public void user_enters_user_id_something_and_new_password_as_something_and_confirm_password_as_something(
			String string1, String string2, String string3) throws InterruptedException {
		ur.setUserId(string1);
		ur.setNewPsd(string2);
		ur.setConfirmPsd(string3);
	}

	@Then("user enters firstname {string} and lastname as {string}")
	public void user_enters_firstname_something_and_lastname_as_something(String string1, String string2)
			throws InterruptedException {
		ur.setFirstName(string1);
		ur.setLastName(string2);
	}

	@Then("user enters email as {string}")
	public void user_enters_email_as_something(String string) throws InterruptedException {
		ur.setEmail(string);
	}

	@Then("user enters phonenumber as {string}")
	public void user_enters_phonenumber_as_something(String string) throws InterruptedException {
		ur.setPhoneNum(string);
	}

	@Then("user enters address1 as {string}")
	public void user_enters_address1_as_something(String string) throws InterruptedException {
		ur.setAddress1(string);
	}

	@Then("user enters address2 as {string}")
	public void user_enters_address2_as_something(String string) throws InterruptedException {
		ur.setAddress2(string);
	}

	@Then("user enters city as {string}")
	public void user_enters_city_as_something(String string) throws InterruptedException {
		ur.setCity(string);
	}

	@Then("user enters state as {string}")
	public void user_enters_state_as_something(String string) throws InterruptedException {
		ur.setState(string);
	}

	@Then("user enters pincode as {string}")
	public void user_enters_pincode_as_something(String string) throws InterruptedException {
		ur.setZip(string);
	}

	@Then("user enters country as {string}")
	public void user_enters_country_as_something(String string) throws InterruptedException {
		ur.setCountry(string);
	}

	@Then("user selects language preference as {string}")
	public void user_selects_language_preference_as_something(String string) throws InterruptedException {
		ur.setLanguage(string);
	}

	@Then("user selects Favourite Category as {string}")
	public void user_selects_favourite_category_as_something(String string) throws InterruptedException {
		ur.setCategory(string);
	}

	@And("user clicks on save button")
	public void user_clicks_on_save_button() throws InterruptedException {
		ur.Save();
	}

	@Then("user clicks on signin button")
	public void user_clicks_on_signin_button() throws InterruptedException {
		lo.Signin();
	}

	@Then("user clears username")
	public void user_clears_username() throws InterruptedException {
		lo.ClearU();

	}

	@Then("user clears password")
	public void user_clears_password() throws InterruptedException {
		lo.ClearP();
	}

	@Then("user enters the username as {string}")
	public void user_enters_the_username_as_something(String string) throws InterruptedException {
		lo.setID(string);

	}

	@Then("user enters the password as {string}")
	public void user_enters_the_password_as_something(String string) throws InterruptedException {
		lo.setUPW(string);

	}

	@Then("user clicks on the login button")
	public void user_clicks_on_the_login_button() throws InterruptedException {
		lo.Login();
	}

	@Then("user clicks on the required product")
	public void user_clicks_on_the_required_product() throws InterruptedException {
		lo.Product();
	}

	@Then("user clicks on the product ID")
	public void user_clicks_on_the_product_id() throws InterruptedException {
		lo.ProductID();
	}

	@Then("user adds product to the cart")
	public void user_adds_product_to_the_cart() throws InterruptedException  {
		lo.Addcart();
	}
	
	

    @Then("user check outs")
    public void user_check_outs() throws InterruptedException  {
        lo.Checkout();
        Thread.sleep(5000);
    }

    
    @Then("user clears userid")
    public void user_clears_userid() throws InterruptedException {
        lo.Uclear();
    }
    
    @Then("user clears userpassword")
    public void user_clears_userpassword() throws InterruptedException {
       lo.PClear();
    }
    



    @When("user enters User ID as {string}")
    public void user_enters_user_id_as_something(String string) throws InterruptedException {
        lo.setUID(string);
    }

    @When("user enters User Password as {string}")
    public void user_enters_user_password_as_something(String string) throws InterruptedException  {
       lo.setPW(string);
    }


    @When("user clicks on login")
    public void user_clicks_on_login() throws InterruptedException  {
       lo.ULogin();
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
	@Then("close browser")
	public void close_browser() throws Throwable {

		driver.quit();
	}

}
