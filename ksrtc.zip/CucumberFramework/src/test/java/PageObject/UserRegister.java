package PageObject;

import StepDefinition.Step1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;

public class UserRegister {
	public WebDriver ldriver;

	public UserRegister(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(xpath = "//*[@id=\"MenuContent\"]/a[3]")
	@CacheLookup
	WebElement Signup;

	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[1]/tbody/tr[1]/td[2]/input")
	@CacheLookup
	WebElement userid;

	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[1]/tbody/tr[2]/td[2]/input")
	@CacheLookup
	WebElement newpsd;

	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[1]/tbody/tr[3]/td[2]/input")
	@CacheLookup
	WebElement confirmpsd;

	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[2]/tbody/tr[1]/td[2]/input")
	@CacheLookup
	WebElement firstname;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[2]/tbody/tr[2]/td[2]/input")
	@CacheLookup
	WebElement lastname;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[2]/tbody/tr[3]/td[2]/input")
	@CacheLookup
	WebElement email;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[2]/tbody/tr[4]/td[2]/input")
	@CacheLookup
	WebElement phonenum;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[2]/tbody/tr[5]/td[2]/input")
	@CacheLookup
	WebElement address1;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[2]/tbody/tr[6]/td[2]/input")
	@CacheLookup
	WebElement address2;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[2]/tbody/tr[7]/td[2]/input")
	@CacheLookup
	WebElement city;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[2]/tbody/tr[8]/td[2]/input")
	@CacheLookup
	WebElement state;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[2]/tbody/tr[9]/td[2]/input")
	@CacheLookup
	WebElement zip;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[2]/tbody/tr[10]/td[2]/input")
	@CacheLookup
	WebElement country;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[3]/tbody/tr[1]/td[2]/select")
	@CacheLookup
	WebElement language;
	
	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/table[3]/tbody/tr[2]/td[2]/select")
	@CacheLookup
	WebElement category;
	

	@FindBy(xpath = "//*[@id=\"CenterForm\"]/form/div/button")
	@CacheLookup
	WebElement save;
	
	
	
	
	public void Save() {
		save.click();
	}
	public void Register() {
		Signup.click();
	}

	public void setUserId(String uid) {
		userid.sendKeys(uid);
	}
	public void setNewPsd(String newp) {
		newpsd.sendKeys(newp);
	}
	public void setConfirmPsd(String cpsd) {
		confirmpsd.sendKeys(cpsd);
	}
	
	public void setFirstName(String fname) {
		firstname.sendKeys(fname);
	}
	
	public void setLastName(String lname) {
		lastname.sendKeys(lname);
	}
	
	public void setEmail(String mail) {
		email.sendKeys(mail);
	}
	

	public void setPhoneNum(String pnum) {
		phonenum.sendKeys(pnum);
	}
	
	public void setAddress1(String add1) {
		address1.sendKeys(add1);
	}
	
	public void setAddress2(String add2) {
		address2.sendKeys(add2);
	}
	

	public void setCity(String ct) {
		city.sendKeys(ct);
	}
	
	public void setState(String st) {
		state.sendKeys(st);
	}
	
	public void setZip(String code) {
		zip.sendKeys(code);
	}
	
	public void setCountry(String ctry) {
		country.sendKeys(ctry);
	}
	
	public void setLanguage(String lp) {
		language.sendKeys(lp);
	}
	
	public void setCategory(String fc) {
		category.sendKeys(fc);
	}

}
