package PageObject;

import StepDefinition.Step1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;

public class Login {
	public WebDriver ldriver;

	public Login(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(xpath = "//*[@id=\"MenuContent\"]/a[2]")
	@CacheLookup
	WebElement signin;
	
	
	@FindBy(xpath = "//*[@id=\"Signon\"]/form/div/label[1]/input")
	@CacheLookup
	WebElement uclear;
	
	@FindBy(xpath = "//*[@id=\"Signon\"]/form/div/label[2]/input")
	@CacheLookup
	WebElement pwclear;
	
	@FindBy(xpath = "//*[@id=\"Signon\"]/form/div/label[1]/input")
	@CacheLookup
	WebElement userid;
	
	@FindBy(xpath = "//*[@id=\"Signon\"]/form/div/label[2]/input")
	@CacheLookup
	WebElement userpw;
	
	
	@FindBy(xpath = "//*[@id=\"Signon\"]/form/div/div/button")
	@CacheLookup
	WebElement login;
	

	@FindBy(xpath = "//*[@id=\"SidebarContent\"]/a[1]")
	@CacheLookup
	WebElement product;
	
	@FindBy(xpath = "//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[1]/a")
	@CacheLookup
	WebElement productid;
	
	@FindBy(xpath = "//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[5]/a")
	@CacheLookup
	WebElement addcart;
	
	
	@FindBy(xpath = "//*[@id=\"Cart\"]/a")
	@CacheLookup
	WebElement checkout;
	
	@FindBy(xpath = "//*[@id=\"Signon\"]/form/div/label[1]/input")
	@CacheLookup
	WebElement clearuid;
	

	@FindBy(xpath = "//*[@id=\"Signon\"]/form/div/label[2]/input")
	@CacheLookup
	WebElement clearpw;
	
	@FindBy(xpath = "//*[@id=\"Signon\"]/form/div/label[1]/input")
	@CacheLookup
	WebElement enteruid;
	
	@FindBy(xpath = "//*[@id=\"Signon\"]/form/div/label[2]/input")
	@CacheLookup
	WebElement enterpw;
	
	

	@FindBy(xpath = "//*[@id=\"Signon\"]/form/div/div/button")
	@CacheLookup
	WebElement clicklogin;
	
	
	
	public void Signin() {
		signin.click();
	}
	
	public void ClearU() {
		uclear.clear();
	}
	
	public void ClearP() {
		pwclear.clear();
	}
	
	public void setID(String uid) {
		userid.sendKeys(uid);
	}
	
	
	public void setUPW(String pw) {
		userpw.sendKeys(pw);
	}
	
	
	public void Login() {
		login.click();
	}
	
	public void Product() {
		product.click();
	}
	
	public void ProductID() {
		productid.click();
	}
	
	public void Addcart() {
		addcart.click();
	}
	
	public void Checkout() {
		checkout.click();
	}
	
	public void Uclear() {
		clearuid.clear();
	}
	

	public void PClear() {
		clearpw.clear();
	}
	
	
	public void setUID(String userid) {
		enteruid.sendKeys(userid);
	}
	
	public void setPW(String upassword) {
		enterpw.sendKeys(upassword);
	}
	
	
	public void ULogin() {
		clicklogin.click();
	}
	
}
